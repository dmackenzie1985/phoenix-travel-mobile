<?php
require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();

//Get route for All Tours
$app->get('/tours','getTours');
function getTours()
{
	try{
		//Get connection
		$dbh=getConnection();
			
		//Now lets craft a SQL select string.
		$sql = "SELECT * from tours";

		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->execute();

		//fetch record and place in array of objects
		$row=$stmt->fetchALL(PDO::FETCH_OBJ);

		//IMPORTANT to close connection after you have finished with it.
		//There could be hundreds of clients connecting to your site.
		//If you dont close connections to database this could
		//slow your system greatly
		$dbh=null;

		//return array of objects in json format
		echo json_encode($row);
	}
	catch(PDOException $e){
		$e->getMessage();
	}

}


//Get route for All Trips
$app->get('/trips','getTrips');
function getTrips()
{
	try{
		//Get connection
		$dbh=getConnection();
			
		//Now lets craft a SQL select string.
		$sql = "SELECT * from trips";

		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->execute();

		//fetch record and place in array of objects
		$row=$stmt->fetchALL(PDO::FETCH_OBJ);

		//IMPORTANT to close connection after you have finished with it.
		//There could be hundreds of clients connecting to your site.
		//If you dont close connections to database this could
		//slow your system greatly
		$dbh=null;

		//return array of objects in json format
		echo json_encode($row);
	}
	catch(PDOException $e){
		$e->getMessage();
	}

}

//Get route for Available Trips For a Tour Number
$app->get('/trips/search/:Tour_No','getAvailableTrips');
function getAvailableTrips($Tour_No)
{
	try{
		//Get connection
		$dbh=getConnection();
			
		//Now lets craft a SQL select string.
		$sql = "SELECT * from trips Where Tour_No =:Tour_No AND Passengers_Booked < Max_Passengers";

		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->bindParam("Tour_No",$Tour_No);
		$stmt->execute();

		//fetch record and place in array of objects
		$row=$stmt->fetchAll(PDO::FETCH_OBJ);

		//IMPORTANT to close connection after you have finished with it.
		//There could be hundreds of clients connecting to your site.
		//If you dont close connections to database this could
		//slow your system greatly
		$dbh=null;
		
		if($row==null)
		{
			echo "No Trips available for that Tour";
		}
		else{
			//return array of objects in json format
			echo json_encode($row);
		}


	}
	catch(PDOException $e){
		$e->getMessage();
	}

}

//Get route all trips for a customer
$app->get('/trips/:id','getCustomerTrips');
function getCustomerTrips($id)
{

	try{
		//Get connection
		$dbh=getConnection();
			
		//Now lets craft a SQL select string.
		$sql = "SELECT trips.Trip_Id, trips.Tour_No, trips.Rego_No, trips.Departure_Date, trips.Passengers_Booked, trips.Max_Passengers,trips.Standard_Amount,trips.Concession_Amount FROM trips, customer_bookings, trip_bookings, customers WHERE customers.Customer_Id = customer_bookings.Customer_Id AND customer_bookings.Trip_Booking_No = trip_bookings.Trip_Booking_No AND trip_bookings.Trip_Id = trips.Trip_Id AND customers.Customer_Id = '".$id."'";

		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->execute();

		//fetch record and place in array of objects
		$row=$stmt->fetchALL(PDO::FETCH_OBJ);

		//IMPORTANT to close connection after you have finished with it.
		//There could be hundreds of clients connecting to your site.
		//If you dont close connections to database this could
		//slow your system greatly
		$dbh=null;

		//return array of objects in json format
		echo json_encode($row);
	
	}
	catch(PDOException $e){
		$e->getMessage();
	}
}

//Post route - Register Customer
$app->post('/customer/addCustomer','addCustomer');
function addCustomer(){
	try{
			
	//Get database connection
	$dbh=getConnection();
	
	//Use slim to get the contents of the HTTP Post request
	$request = \Slim\Slim::getInstance()->request();
	
	//The request is in JSON format so we need to decode it
	$q = json_decode($request->getBody());
	
	$hash = md5($q->Password);
			
	//Now lets craft a SQL select string.
	$sql = "INSERT INTO customers(Customer_Id, First_Name, Middle_Initial, Last_Name, Street_No, Street_Name, Suburb, Postcode, Email, Phone, Enabled, Akey) values (:Customer_Id,:First_Name,:Middle_Initial,:Last_Name,:Street_No,:Street_Name,:Suburb,:Postcode,:Email,:Phone,:Enabled,:Akey)";
	
	//Make sql string into an SQL statement and execute the statement
	$stmt=$dbh->prepare($sql);
	$stmt->bindParam("Customer_Id",$q->Customer_Id);
	$stmt->bindParam("First_Name",$q->First_Name);
	$stmt->bindParam("Middle_Initial",$q->Middle_Initial);
	$stmt->bindParam("Last_Name",$q->Last_Name);
	$stmt->bindParam("Street_No",$q->Street_No);
	$stmt->bindParam("Street_Name",$q->Street_Name);
	$stmt->bindParam("Suburb",$q->Suburb);
	$stmt->bindParam("Postcode",$q->Postcode);
	$stmt->bindParam("Email",$q->Email);
	$stmt->bindParam("Phone",$q->Phone);
	$stmt->bindParam("Enabled",$q->Enabled);
	$stmt->bindParam("Akey",$hash);
		
	$stmt->execute();
	
	$row=$stmt->fetch(PDO::FETCH_OBJ);
	
	//IMPORTANT to close connection after you have finished with it
	$dbh=null;	
	}
	catch(PDOException $e){
		$e->getMesage();
	}
}

//Put route - Manage customer details
$app->put('/customer/updateCustomer','updateCustomer');
function updateCustomer(){
	try{
		//Get database connection
		$dbh=getConnection();
		
		//Use slim to get the contents of the HTTP Post request
		$request = \Slim\Slim::getInstance()->request();
		
		//The request is in JSON format so we need to decode it
		$q = json_decode($request->getBody());
		
		$hash = md5($q->Password);
		
		//Create SQL UPDATE STRING
		$sql = "UPDATE customers set First_Name=:First_Name,Middle_Initial=:Middle_Initial,Last_Name=:Last_Name,Street_No=:Street_No,Street_Name=:Street_Name,Suburb=:Suburb,Postcode=:Postcode,Email=:Email,Phone=:Phone,Enabled=:Enabled,Akey=:Akey Where Customer_Id=:Customer_Id";
				
		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->bindParam("Customer_Id",$q->Customer_Id);
		$stmt->bindParam("First_Name",$q->First_Name);
		$stmt->bindParam("Middle_Initial",$q->Middle_Initial);
		$stmt->bindParam("Last_Name",$q->Last_Name);
		$stmt->bindParam("Street_No",$q->Street_No);
		$stmt->bindParam("Street_Name",$q->Street_Name);
		$stmt->bindParam("Suburb",$q->Suburb);
		$stmt->bindParam("Postcode",$q->Postcode);
		$stmt->bindParam("Email",$q->Email);
		$stmt->bindParam("Phone",$q->Phone);
		$stmt->bindParam("Enabled",$q->Enabled);
		$stmt->bindParam("Akey",$hash);
		
		$stmt->execute();
		
		$row=$stmt->fetch(PDO::FETCH_OBJ);
		
		//IMPORTANT to close connection after you have finished with it
		$dbh=null;	
	}
	catch(PDOException $e){
		$e->getMessage();
	}
}

//Post Route -Book a Trip
$app->post('/customer/addBooking','addBooking');
function addBooking(){
	try{
		//Get database connection
		$dbh=getConnection();
		
		//Use slim to get the contents of the HTTP Post request
		$request = \Slim\Slim::getInstance()->request();
		
		//The request is in JSON format so we need to decode it
		$q = json_decode($request->getBody());
		
		//Now lets craft a SQL select string.
		$sql = "INSERT INTO customer_bookings(Trip_Booking_No,Customer_Id,Num_Concessions,Num_Adults) values (:Trip_Booking_No,:Customer_Id,:Num_Concessions,:Num_Adults)";
				
		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->bindParam("Trip_Booking_No",$q->Trip_Booking_No);
		$stmt->bindParam("Customer_Id",$q->Customer_Id);
		$stmt->bindParam("Num_Concessions",$q->Num_Concessions);
		$stmt->bindParam("Num_Adults",$q->Num_Adults);
		$stmt->execute();
		
		$row=$stmt->fetch(PDO::FETCH_OBJ);
		
		//IMPORTANT to close connection after you have finished with it
		$dbh=null;	
	}
	catch(PDOException $e){
		$e->getMessage();
	}
}

//View Tour itinerary
//Get route - Tour Itinerary
$app->get('/tour/itinerary/:Trip_Id','getTourItinerary');
function getTourItinerary($Trip_Id)
{
	//Get connection
	$dbh=getConnection();
		
	//Now lets craft a SQL select string.
	$sql = "SELECT * from Itineraries where Trip_Id = ".$Trip_Id;

	//Make sql string into an SQL statement and execute the statement
	$stmt=$dbh->prepare($sql);
	$stmt->execute();

	//fetch record and place in array of objects
	$row=$stmt->fetchALL(PDO::FETCH_OBJ);

	//IMPORTANT to close connection after you have finished with it.
	//There could be hundreds of clients connecting to your site.
	//If you dont close connections to database this could
	//slow your system greatly
	$dbh=null;

	//return array of objects in json format
	echo json_encode($row);
	
	try{
		
	}
	catch(PDOException $e){
		$e->getMessage();
	}
}

//Post - Route Review Trip
$app->post('/customer/addReview','addReview');
function addReview(){
	try{
		//Get database connection
		$dbh=getConnection();
		
		//Use slim to get the contents of the HTTP Post request
		$request = \Slim\Slim::getInstance()->request();
		
		//The request is in JSON format so we need to decode it
		$q = json_decode($request->getBody());
		
		//Now lets craft a SQL select string.
		$sql = "INSERT INTO customer_reviews(Trip_Id,Customer_Id,Rating,General_Feedback,Likes,Dislikes) values (:Trip_Id,:Customer_Id,:Rating,:General_Feedback,:Likes,:Dislikes)";
				
		//Make sql string into an SQL statement and execute the statement
		$stmt=$dbh->prepare($sql);
		$stmt->bindParam("Trip_Id",$q->Trip_Id);
		$stmt->bindParam("Customer_Id",$q->Customer_Id);
		$stmt->bindParam("Rating",$q->Rating);
		$stmt->bindParam("General_Feedback",$q->General_Feedback);
		$stmt->bindParam("Likes",$q->Likes);
		$stmt->bindParam("Dislikes",$q->Dislikes);
		$stmt->execute();
		
		$row=$stmt->fetch(PDO::FETCH_OBJ);
		
		//IMPORTANT to close connection after you have finished with it
		$dbh=null;	
	}
	catch(PDOException $e){
		$e->getMessage();
	}
}


//GET route
$app->get('/',function(){
	$template= <<<EOT
	<!DOCTYPE html>
	<html><head>
	<title>404 Page Not Found</title>
	<body><h1>404 Page Not Found</h1>
	<p>The page you are looking for could not be found. Dave M</p>
	</body></html>
EOT;
	echo $template;
});

function getConnection()
{
	$dbh = null;
	try{
		//First we need to get a connection object to the database
		$hostname = '127.0.0.1';
		$username = 'root';
		$password = 'root';
		$dbname = 'phoenixmobile';
		$dbh = new PDO("mysql:host=$hostname;dbname=$dbname",$username,$password);
	}	
	catch(PDOException $e)
	{
		echo $e->getMessage();
	}
	
	return $dbh;
}

$app->run();

?>